<?php
/**
 * Created by PhpStorm.
 * User: rofi
 * Date: 28-Mar-18
 * Time: 3:16 AM
 */
//as bootstrap.php loads these helpers the session is started automatically
session_start();
//require_once '../bootstrap.php';


//this is used flush message
//example flash();
function flash()
{
    //display error
    if(isset($_SESSION['error'])){
         echo"<div class='alert alert-danger text-center'>
						<button class='close'>&times;</button>
						".ucwords($_SESSION['error'])."
					</div>
					";
                    unset($_SESSION['error']);
         }


    //display success
    if(isset($_SESSION['success'])){
        echo"<div class='alert alert-success text-center alert-dismissable'>
						<button class='close'>&times;</button>
						".ucwords($_SESSION['success'])."
					</div>
					";
        unset($_SESSION['success']);
    }


    //display info message
    if(isset($_SESSION['info'])){
        echo"<div class='alert alert-info text-center '>
						<button class='close'>&times;</button>
						".ucwords($_SESSION['info'])."
					</div>
					";
        unset($_SESSION['success']);
    }
}


//if not loged in redirect to login

