<?php
echo date('y-m-d');