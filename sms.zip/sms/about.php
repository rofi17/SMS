<?php require_once './includes/header.php';?>
<?php LogInCheck(); ?>
    <h1>An Office Stock Management System</h1>
    <p>For NIC ASSAM</p>
    <p>Version: <strong><?php echo APPVERSION; ?></strong></p>
<?php require_once './includes/footer.php';?>