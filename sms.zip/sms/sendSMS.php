<?php
// Authorisation details.
$username = "contact.knowitnow@gmail.com";
$hash = "2fd8190e81c4d03a4fb5963878a01259eb57aafdb411ce24f24e3eea72791daa";

// Config variables. Consult http://api.textlocal.in/docs for more info.
$test = "0";

// Data for text message. This is the text message data.
$sender = "TXTLCL"; // This is who the message appears to be from.
$numbers = ""; // A single number or a comma-seperated list of numbers
$message = "good morning hav a good day from ro1f12";
// 612 chars or less
// A single number or a comma-seperated list of numbers
$message = urlencode($message);
$data = "username=".$username."&hash=".$hash."&message=".$message."&sender=".$sender."&numbers=".$numbers."&test=".$test;
$ch = curl_init('http://api.textlocal.in/send/?');
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$result = curl_exec($ch);// This is the result from the API
print_r($result);
curl_close($ch);
?>