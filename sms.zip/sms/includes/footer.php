</div>
<div class="container-fluid footer navbar-fixed-bottom">
    <hr>
<footer class="" >

            <p>&copy; Copyright 2017-<?php echo date('Y');?> | All Rights Reserverd <br> This Website Is Developed By Masud Alam Rofi | powered by
            Bootstrap <br>SITE VERSION <?php echo APPVERSION;?>
            </p>

 </footer>
<!--adding scripts-->
<script src="./assets/jquery/jquery-3.2.1.js"></script>
<script src="./assets/bootstrap/js/bootstrap.min.js"></script>
<script src="./assets/plugins/datatables/dataTables.bootstrap.js"></script>
<script src="./assets/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="./assets/custom/js/custom.js"></script>
<script src="./assets/plugins/moment/moment.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/3.1.1/js/bootstrap-datetimepicker.min.js"></script>
</div>
</body>
</html>