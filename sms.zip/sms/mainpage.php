<?php require_once './includes/header.php'; ?>
<?php LogInCheck(); ?>
<?php
    require_once './includes/navbar.php';
    //flash message
    flash();
?>
<?php require_once './includes/footer.php'; ?>
