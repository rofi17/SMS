<?php require_once './includes/header.php';?>
<?php LogInCheck(); ?>
this is registration page
<?php require_once './includes/footer.php';?>
